This folder contains the files for the hyper-parameter analysis of the PGL method on synthetic data.  

Use the code HyperParameterAnalysis.m, and the results are in HyperParam.mat file. 

Run the code for getting the code Fig_4a.m to get the plot as in paper. 